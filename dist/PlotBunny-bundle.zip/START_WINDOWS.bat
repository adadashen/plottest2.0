@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

echo [Plot Bunny] Starting...

set "PY_CMD="
if exist ".venv\Scripts\python.exe" (
    set "PY_CMD=.venv\Scripts\python.exe"
) else (
    where py >nul 2>nul
    if %errorlevel%==0 (
        set "PY_CMD=py -3"
    ) else (
        where python >nul 2>nul
        if %errorlevel%==0 (
            set "PY_CMD=python"
        )
    )
)

if "%PY_CMD%"=="" (
    echo.
    echo [ERROR] Python 3 not found.
    echo Please install Python 3.10+ from https://www.python.org/downloads/windows/
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [Plot Bunny] Creating virtual environment...
    %PY_CMD% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

if not exist ".venv\.deps_installed" (
    echo [Plot Bunny] Installing dependencies (first run)...
    .venv\Scripts\python.exe -m pip install --upgrade pip
    if errorlevel 1 (
        echo [ERROR] pip upgrade failed.
        pause
        exit /b 1
    )
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Dependency installation failed.
        pause
        exit /b 1
    )
    type nul > ".venv\.deps_installed"
)

echo [Plot Bunny] Launching...
set "APP_HOST=127.0.0.1"
set "APP_OPEN_BROWSER=1"

set "APP_PORT="
for %%P in (8001 8002 8003 8004 8005 8010) do (
    .venv\Scripts\python.exe -c "import socket,sys; s=socket.socket(); s.settimeout(0.3); ok=s.connect_ex(('127.0.0.1', %%P)); s.close(); sys.exit(0 if ok!=0 else 1)"
    if not errorlevel 1 (
        set "APP_PORT=%%P"
        goto :port_selected
    )
)

set "APP_PORT=8001"
:port_selected
echo [Plot Bunny] Using port %APP_PORT%
echo %APP_PORT%> PORT.txt
.venv\Scripts\python.exe run_app.py
set "EXIT_CODE=%errorlevel%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo [ERROR] Plot Bunny exited with code %EXIT_CODE%.
    pause
)

exit /b %EXIT_CODE%

